# Modular changelog

## Versions

- [0.2.0](#070)
- [0.1.0](#070)

<br>

---

## Changes

<br>

### 0.2.0

- Library restructured
- Minor fixes
- Clean up
- Config files better handled

<br>

### 0.1.0

- Library setup
