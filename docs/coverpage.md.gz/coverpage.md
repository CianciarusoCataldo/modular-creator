# modular <img src="https://user-images.githubusercontent.com/47371276/153878422-16c9d20f-d0f0-4940-8b67-3366094b66f7.png" alt="" width="40"/>

> Setup and configure your web app with few steps

[Get Started](#getting-started)
[Docs](#main)
[Github](https://github.com/cianciarusocataldo/modular-ui)
[NPM](https://www.npmjs.com/package/@cianciarusocataldo/modular-ui)
